export default function AboutMe() {
    return (
      <section id="AboutMe" className="about--section">
        <div className="about--section--img">
          <img src="./img/about-me.png" alt="About Me" />
        </div>
        <div className="hero--section--content--box about--section--box">
          <div className="hero--section--content">
            <p className="section--title">HAQIMDA</p>
            <h1 className="skills-section--heading">Men haqimda</h1>
            <p className="hero--section-description">
              Men dasturlash soxasida ko`pgina loyixalar va veb dizaynlar yaratdim. 
              Dasturlashda Backend fa frontend qismlarini chuqur o`rgandim.
            </p>
            <p className="hero--section-description">
              Maqsadim yanada ko`proq dasturlash tillarini o`rganish va ularda end oddiy saytdan 
              boshlab eng professional saytlar yaratishdan iboratdir.
            </p>
          </div>
        </div>
      </section>
    );
  }
  